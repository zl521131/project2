import Vue from 'vue'
import VueRouter from 'vue-router'


Vue.use(VueRouter)

const routes = [
  // 首页路由
  {
    path: '/index',
    component: () => import('../views/Home.vue')
  },
  // 管理员路由
  {
    path: '/admin/show',
    component: () => import('../views/admin/show.vue')
  },
  {
    path: '/admin/index',
    component: () => import('../views/admin/index.vue')
  },
  {
    path: '/admin/add',
    component: () => import('../views/admin/add.vue')
  },
  {
    path: '/admin/edit',
    component: () => import('../views/admin/edit.vue')
  },
  // 用户路由
  {
    path: '/user/index',
    component: () => import('../views/user/index.vue')
  },
  {
    path: '/user/info',
    component: () => import('../views/user/info.vue')
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
