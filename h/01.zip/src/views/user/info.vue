<template>
    <div>
        <div class="top">
            <el-page-header class="tou" @back="goBack" content="用户详情"></el-page-header>
        </div>
        <div class="main">
            <ul>
                <li>
                    <span>头像</span>
                    <img src="../../assets/logo.png" alt="">
                </li>
                <li>
                    
                </li>
                <li>

                </li>
                <li>

                </li>
            </ul>
        </div>
    </div>
</template>

<script>
export default {
    methods: {
        goBack() {
            this.$router.push("/user/index");
        }
    }
}
</script>

<style>
    .top{
        width: 100%;
        height: 40px;
        background-color: rgb(255, 255, 255);
    }
    .tou{
        line-height: 40px;
    }
    .main{
        float: left;
    }
    .main li{
        float: left;
        margin: 60px;
    }
    .main li img{
        width: 80px;
        height: 80px;
    }
</style>